# GRAFICACION_UASLP
Examen segundo parcial parte B.
