# Sistema solar simple.

Modelo del sistema solar hecho con openGL.
El modelo es fiel a la realidad en algunos 
aspectos o almenos intenta serlo.

1)Distancia de los planetas al sol.......(No).
2)Proporcion de los planetas entre si....(Si).
3)Proporcion del Sol.....................(No).
4)velocidad proporcional de las orbitas..(Si).
5)color de los cuerpos celestes..........(si).
